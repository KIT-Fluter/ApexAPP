package com.example.apex_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
